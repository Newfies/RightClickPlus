# Fake Ext [F-Ext]
F-Ext is a chrome extension built for anyone who wants to display the extension icon of their choice!

## Status
![ReleasedBadge](https://img.shields.io/badge/Is_Released-Not_Yet-red)
![ReleasedBadge](https://img.shields.io/badge/Latest_Version-1.1.0-green)

## Links
[![ReleasedBadge](https://img.shields.io/badge/Link-Wiki-blue)](https://www.github.com/Newfies/fakeext/wiki)

## Notice
All information from README.md and from now on will be posted to the wiki.
